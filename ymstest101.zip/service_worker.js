var currentTabId = '';
chrome.tabs.onActivated.addListener(function(activeInfo) {currentTabId = activeInfo.tabId;chrome.tabs.update(currentTabId, {autoDiscardable: false});console.log('Current Tab: ' + currentTabId);});
