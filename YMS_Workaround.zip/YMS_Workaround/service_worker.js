var currentTabId = '';
chrome.tabs.onActivated.addListener(function(activeInfo) {currentTabId = activeInfo.tabId;console.log('Current Tab: ' + currentTabId);});
