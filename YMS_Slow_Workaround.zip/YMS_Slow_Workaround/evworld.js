window.sampleTimer = setInterval(function() {
    $('[role="log"].ui-helper-hidden-accessible [style="display: none;"]').remove();
}, 5);